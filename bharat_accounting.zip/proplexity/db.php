
<?php
class Database {
    private $host = "localhost";
    private $db_name = "gst_accounting";
    private $username = "gstwork";
    private $password = "gstwork@123";
    public $conn;

    public function getConnection() {
        $this->conn = null;
        
        try {
            $this->conn = new PDO("mysql:host={$this->host};dbname={$this->db_name};charset=utf8mb4",
                $this->username, $this->password);
            $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $this->conn->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
            $this->conn->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);
        } catch(PDOException $exception) {
            echo "Connection error: " . htmlspecialchars($exception->getMessage());
            exit;
        }
        
        return $this->conn;  // Move this BEFORE the catch block
    }
}
?>

